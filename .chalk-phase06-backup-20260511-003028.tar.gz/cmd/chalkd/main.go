// Command chalkd is the chalk server daemon.
package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/google/uuid"

	chalk "github.com/scuq/chalk"
	"github.com/scuq/chalk/internal/config"
	"github.com/scuq/chalk/internal/migrate"
	"github.com/scuq/chalk/internal/server"
	"github.com/scuq/chalk/internal/store"
	"github.com/scuq/chalk/internal/version"
)

func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, "chalkd: "+err.Error())
		os.Exit(1)
	}
}

func run(args []string) error {
	cfg, err := config.Load(args)
	if err != nil {
		if errors.Is(err, config.ErrVersionRequested) {
			fmt.Println(version.String())
			return nil
		}
		return err
	}

	if cfg.InstanceID == "" {
		cfg.InstanceID = "instance-" + uuid.NewString()[:8]
	}

	log.SetFlags(log.LstdFlags | log.LUTC)
	log.Printf("starting %s (instance=%s listen=%s tls=%s log=%s)",
		version.String(), cfg.InstanceID, cfg.Listen, cfg.TLSMode, cfg.LogLevel)

	if cfg.DBURL == "" {
		return errors.New("missing database URL: set --db-url or CHALK_DB_URL")
	}

	connectCtx, cancelConnect := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancelConnect()

	st, err := store.Open(connectCtx, cfg.DBURL)
	if err != nil {
		return fmt.Errorf("connect db: %w", err)
	}
	defer st.Close()
	log.Printf("connected to database")

	migs, err := migrate.Load(chalk.Migrations, chalk.MigrationsDir)
	if err != nil {
		return fmt.Errorf("load migrations: %w", err)
	}
	log.Printf("loaded %d migration(s)", len(migs))

	results, err := migrate.Run(connectCtx, st.Pool, migs, log.Printf)
	if err != nil {
		return fmt.Errorf("apply migrations: %w", err)
	}
	applied := 0
	for _, r := range results {
		if !r.Skipped {
			applied++
		}
	}
	log.Printf("migrations: %d total, %d applied, %d already-applied",
		len(results), applied, len(results)-applied)

	// Pre-create monthly partitions for the messages table. Doing this here
	// (post-migrations, pre-Serve) means partition existence is part of
	// startup correctness rather than a side effect of the running loop.
	if err := st.EnsureMessagePartitions(connectCtx, time.Now().UTC()); err != nil {
		return fmt.Errorf("ensure partitions: %w", err)
	}
	log.Printf("partitions ensured for current and next month")

	// Ensure the placeholder "default" channel exists. This is a runtime
	// concern, not a migration concern: a fresh DB has no users yet, so a
	// migration cannot reference one. The default channel is system-owned
	// (created_by IS NULL).
	if err := st.EnsureDefaultChannel(connectCtx); err != nil {
		return fmt.Errorf("ensure default channel: %w", err)
	}
	log.Printf("default channel ensured")

	if cfg.MigrateOnly {
		log.Printf("--migrate-only set; exiting")
		return nil
	}

	srv, err := server.NewServer(server.Options{
		Listen:     cfg.Listen,
		Store:      st,
		Hub:        server.NewHub(),
		WSConfig:   server.DefaultWSConfig(),
		InstanceID: cfg.InstanceID,
		Logger:     log.Default(),
	})
	if err != nil {
		return fmt.Errorf("server: %w", err)
	}

	if cfg.PrintListen {
		fmt.Printf("listening on %s\n", srv.Addr())
	}
	if cfg.ListenInfoFile != "" {
		if err := writeListenInfo(cfg.ListenInfoFile, srv.Addr().String()); err != nil {
			return fmt.Errorf("write listen-info-file: %w", err)
		}
		defer os.Remove(cfg.ListenInfoFile)
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	errCh := make(chan error, 1)
	go func() {
		err := srv.Serve(ctx)
		if err != nil && !errors.Is(err, http.ErrServerClosed) {
			errCh <- err
		}
		close(errCh)
	}()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	select {
	case sig := <-sigCh:
		log.Printf("received %s, shutting down (grace=%s)", sig, cfg.ShutdownGrace)
	case err, ok := <-errCh:
		if ok && err != nil {
			return fmt.Errorf("serve: %w", err)
		}
		return nil
	}

	cancel()
	select {
	case <-errCh:
	case <-time.After(cfg.ShutdownGrace + 5*time.Second):
		return errors.New("server shutdown timed out")
	}
	log.Printf("clean shutdown")
	return nil
}

func writeListenInfo(path, addr string) error {
	dir := "."
	if d := dirOf(path); d != "" {
		dir = d
	}
	tmp, err := os.CreateTemp(dir, ".listen-info-*")
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	defer func() { _ = os.Remove(tmpName) }()
	if _, err := tmp.WriteString(addr + "\n"); err != nil {
		_ = tmp.Close()
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	return os.Rename(tmpName, path)
}

func dirOf(path string) string {
	for i := len(path) - 1; i >= 0; i-- {
		if path[i] == '/' || path[i] == '\\' {
			return path[:i]
		}
	}
	return ""
}
